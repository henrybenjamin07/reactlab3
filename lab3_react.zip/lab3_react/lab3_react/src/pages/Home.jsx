import Header from "../Components/header"
import Header from "../Components/footer"

const Home = () => {
    return(
        <Header/>
    )
}